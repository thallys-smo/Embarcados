//
// Created by grilo on 20/07/23.
//

#ifndef MANOPLA_SYSTEM_IDENTIFICATION_TEST_UTILS_H
#define MANOPLA_SYSTEM_IDENTIFICATION_TEST_UTILS_H

#include <cstdint>
#include <chrono>

uint64_t getCurrentEpochMicroseconds();

#endif //MANOPLA_SYSTEM_IDENTIFICATION_TEST_UTILS_H
